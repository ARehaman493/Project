package com.example.Rehaman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RehamanApplication {

	public static void main(String[] args) {
		SpringApplication.run(RehamanApplication.class, args);
	}

}
