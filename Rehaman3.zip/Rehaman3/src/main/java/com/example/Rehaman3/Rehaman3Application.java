package com.example.Rehaman3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rehaman3Application {

	public static void main(String[] args) {
		SpringApplication.run(Rehaman3Application.class, args);
	}

}
