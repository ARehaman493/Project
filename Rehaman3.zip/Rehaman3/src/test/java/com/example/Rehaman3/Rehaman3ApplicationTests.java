package com.example.Rehaman3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rehaman3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
